# 修复六项架构与逻辑审查发现

## 任务信息

- 任务 ID：TASK-20260906-001
- 状态：进行中
- 任务日期：2026-09-06
- 创建时间：2026-09-06 10:48:57 +08:00
- 开始时间：2026-09-06 10:48:57 +08:00
- 最后更新时间：2026-09-06 14:52:25 +08:00
- 完成时间：未完成
- 创建路径：docs/tasks/pending/2026-09-06/fix-six-architecture-review-findings.md
- 归档路径：docs/tasks/completed/<实际完成日期>/fix-six-architecture-review-findings.md
- 优先级：高；涉及运行中 Android 配置、并发提交、Socket 内存与错误合同。
- 关键词：Android、LAN、apply、Rules、竞态、Socket、资源预算、EOF、外部包观测

## 背景、目标与范围

用户先要求审查现有架构与逻辑，后明确要求“处理一下”。本任务修复已报告的 2 项 P1 和 4 项 P2，补充可重复回归和独立整体审查。基线为当前 HEAD 5fd8bfbb；本次开始时已有文档索引及 2026-09-05/06 任务与证据改动，全部保留。

范围：Android LAN 热协调的活动配置身份；Socket 诊断预分配和读取块约束；规则创建重复提交与迟到保存；Exchange EOF 元数据与 Socket 外部错误观测。

不在范围：未证实的 Android 多控制端 epoch 问题、其他功能改造、新依赖、数据库迁移、真实外部业务、远程 CI、发布和提交代码。本地修复不能代替 Android 真机/TUN 或发布验收。

## 需求确认记录与就绪门禁

- 用户“处理一下”确认执行上一轮六项问题的修复及回归验证。
- 五项行为修复以当前需求/代码合同为准：保存不等于应用；同一次保存仅提交一次；迟到结果不覆盖新选择；失败保留真实阶段/方向；两种协议保持相同外部错误关联字段。
- Socket 诊断预算按当前事件数与逻辑字节预算执行，不增加任意默认上限。
- 尚未确认：Socket 单次读取缓冲绝对上限。已通过结构化问题提出 1 MiB 推荐值与 16 MiB 选项；用户答复前不修改该上限或静默裁剪配置。
- 五项行为修复及诊断队列分配：输入、输出、现状、预期、根因及可判定回归均明确；就绪检查 PASS，进入实施时间 2026-09-06 10:48:57 +08:00。
- 读取块上限分支：待确认，仅继续调查/构造非危险测试；不阻塞其他独立分支。

## 现象、证据与根因

| 项目 | 当前已验证现象 / 复现 | 预期依据 | 已确认根因与影响 |
| --- | --- | --- | --- |
| P1 Android | 运行中 Profile 仅保存新目标应用/弱网参数，LAN 地址改变后 status 路径以最新保存 Profile 构建 apply_active/apply；静态调用链已核对，尚无真机复现 | requirements.md 363-374：仅显式 start/apply 应用 Profile；现存活动 LAN 只允许刷新端点 | endpoint_reconciliation 未比较活动 Profile 指纹，持久草稿进入隐式应用路径 |
| P1 Socket 内存 | 有效上游下 u32::MAX 读取块/事件容量均通过校验；with_capacity 和 vec! 在预算/取消检查前直接预分配；未执行危险巨额分配 | SocketRuntimeLimits 显式资源合同；诊断队列同时受数量和字节预算限制 | 诊断容量直接变预分配；读取块无已确认上限，资源耗尽可使进程退出 |
| P2 重复创建 | 临时副本两次 Save 交错 materialize，期望一次 rule_id:null 请求，实际两次；原测试失败日志已保留 | 一次用户保存事务只创建一条规则 | 子组件锁未覆盖 materialize，父回调捕获旧 pending |
| P2 迟到保存 | Save A 未返回时选择 B，B 已显示后 A 响应覆盖编辑器；新增断言失败 | 已存在选择代次保护，旧异步结果不得覆盖当前选择 | save 写回未绑定选择代次 |
| P2 EOF 元数据 | Server 应答前 EOF，返回 Error 的 code/stage/direction 均为空；新增 Read 断言失败 | exchange-pipeline.md 的强类型错误元数据合同 | Exchange::fail 仅日志记录已知 read/downstream，未放入返回错误 |
| P2 外部错误观测 | Socket 外部包失败的 method/request_id 等未进入 ExchangeObservation；同 HTTP 断言失败 | HTTP 已有 typed external failure 投影与 UI 解析合同 | failed_with_context 的 Socket 分支漏投影 external_* 字段 |

历史依据只作定位：2026-09-05 架构记录曾暂停的 HTTP 风险不作为本任务发现。当前源码与新测试为权威。未知：真实设备网络切换、跨平台/远程业务结果；不会把本地测试描述为真机或发布通过。

## 最小改动与最优设计

| 方案 | 分析 |
| --- | --- |
| 最小改动（采用） | 在现有 Android reconciliation 校验活动身份；规则保存持有同一异步所有权并隔离迟到写回；Socket 队列按需分配并遵守既有预算；EOF 使用已有错误分类；补全 Socket 外部字段。沿用现有端口、领域验证与测试，不增加新依赖或双路径。 |
| 最优设计 | 活动运行事实与持久草稿分开；一次保存事务持有稳定所有权；资源在分配前受明确合同约束；错误与观测在正确边界完整投影。上述局部边界修复即可满足，无需新增框架或改变协议拓扑。 |

## 小任务与所有权

| ID | 内容 / 所有权 | 依赖 / 并行 | 状态 | 验收 |
| --- | --- | --- | --- | --- |
| S1 | Android LAN：infrastructure/adapters/android_adb 与必要 application Android 文件 | 可并行；不碰 UI、Socket | 待实现 | 保存 Profile 漂移不发 apply；纯 LAN 端点变化仍正确热协调；显式 Apply 保持 |
| S2 | 规则 UI：src/features/rules 的编辑、保存与回归 | 可并行；不碰后端 | 待实现 | 快速重复点击只保存一次；迟到完成不覆盖新选择；错误后可继续编辑 |
| S3 | Exchange：crates/exchange 与对应 proxy EOF 映射测试 | 可并行；主 Agent | 待实现 | 真实 EOF 保留 Read/Downstream 与现有分类；Socket 外部字段完整 |
| S4 | Socket 资源：proxy/socket_relay observer/io/config、domain/application 验证与必要绑定 | 诊断部分可并行；上限依赖确认；不得与 S3 共改文件 | 待确认 | 极值不触发初始巨额分配；预算/错误/取消及边界测试通过 |
| S5 | 集成、文档、证据、独立整体审查与归档 | S1-S4 完成后；主 Agent 独占索引 | 待实现 | 全部回归、静态检查与独立 APPROVE；未验证层明确记录 |

所有 Agent 共享工作区，不得撤销他人修改；子 Agent 仅修改分配范围，不登记编号、不操作任务索引、不提交。共享文件/合同冲突先报告主 Agent。整批全部结束并完成集成验证后才开始整体对抗审查。

## 测试与文档计划

采用 test-driven-development 技能；先保存回归 RED 输出，再实施并保存 GREEN。最小验证为 Android fake runner 控制请求/身份测试、规则组件交互测试、Exchange/Socket 集成与诊断内存预算测试；完成后运行 Rust workspace 全量、前端全量、类型、零警告 lint、fmt、strict Clippy、架构和源文件尺寸门禁。只执行受影响检查；不触发 CI。

证据计划：android-active-profile、rules-save-ownership、exchange-error-observation、socket-resource-limits、integrated-verification。每项在 docs/testing/evidence/2026-09-06/TASK-20260906-001/ 下归档 README、metadata、实际测试源码/资源、输入输出和复测入口；临时探针与正式验收区分。UI 使用真实组件测试的操作/状态/可访问名断言；原生 App 点击与 Android 真机不适用本次本地代码回归验收，记 NOT_RUN，不能替代设备/发布验收。

后续复用：
- 父任务 TASK-20260905-001，父用例 MANUAL-RECOVERY-001，父证据 docs/testing/evidence/2026-09-05/TASK-20260905-001/manual-recovery/；保持手动恢复与有效 LAN 热协调，新增保存配置漂移反例。
- 父任务 TASK-20260905-004，父用例 final-verification，父证据 docs/testing/evidence/2026-09-06/TASK-20260905-004/final-verification/；保持统一 Exchange、raw 特化及原有回归行为，新增四项原测试遗漏的边界。
- 上一轮临时复现为本任务起因，复制实际报告、日志和新增测试资源；初始错误 fixture 保留并标注，不算产品 RED。

文档同步：只在相关架构/需求文档补充已落地的行为/明确确认的资源合同，不重写历史任务；任务与索引写入遵守全局锁。

## 对抗审查计划

各并行小任务不提前进行单独审查，统一在全部集成且测试通过后由未实施该任务的独立 code-reviewer/architect 检查六项根因、合同、并发/资源/错误边界和证据；任务相关 P0/P1/P2 必须清零并取得 APPROVE 才归档。

## 实施、验收与完成记录

- 实施记录：尚未修改源码，已核对当前基线、复现与现有工作区修改。
- 修改文件：本任务文档及 docs/README.md 任务入口；源码待实施后补全。
- 附加文件与测试结果：待各用例完成后登记稳定链接。
- CI：NOT_RUN，用户未要求。
- 未确认事项：Socket 单次读取缓冲上限；其余分支已就绪。
- 完成总结：未完成。

## 第一批实现与复审进展

- 2026-09-06：S1 Android Profile 指纹门禁及冻结端点更新完成，两个漂移 RED 用例修复后通过；进一步锁定热更新只改 proxy_host、保留冻结 IP/端口/Profile/epoch，聚焦与 Clippy 通过。
- S2 规则保存覆盖物化到提交全过程，晚到结果按代次隔离；保留取消能力和旧保存失败提示。新增六项回归，规则模块 43 项通过。
- S3 EOF 复用现有 READ_FAILED/Read/Downstream，真实本机 TCP 证明只发一个下游读取失败终态；Socket external_* 关联字段补齐，Exchange 27 和 Socket 63 项聚焦通过。
- S4 诊断队列改为按需增长；usize::MAX 容量加 512 字节预算可构造并正确淘汰。读取块绝对上限尚未获得具体用户选择，不进行该项实现。
- 首次稳定全量：Rust 45 组 1645 项、前端 546 项通过；随后补强取消/错误提示与冻结路由测试，最终复测 Rust 1645、前端 548 通过，源码 1352 文件前后稳定，源码快照逐字节一致。类型、零警告 lint、严格 Clippy、格式、架构、500 行和前端构建通过。首轮 Clippy 测试分号问题已修正；原失败日志保留。
- 独立 architect 对所审实现给出 CLEAR，但任务闭环仍 BLOCK：读取块上限待确认、正式证据待入库。
- 独立 code-reviewer 又复现范围内 P2：新建草稿物化期间再次 New，组件同身份复用，旧物化仍可保存。该发现重新打开 S2，以显式编辑会话身份修复，补 New/同身份替换回归。不得把之前的局部通过写成最终 APPROVE。
- 外部错误字段的观测总预算候选仍在复审确认，确认前不当成缺陷或改变既有预算。
- 用户后续询问评分并要求其他任务继续，已说明约 80/100 属于工程判断、不是覆盖率；随后“继续”维持原修复任务，并未明确选择读取缓冲上限。
- 当前完整证据保留于本机临时任务目录，待复审修复后转入正式 TASK 用例目录；未提交、未发布、未触发 CI，未执行真机/TUN/长稳或外部业务验收。
