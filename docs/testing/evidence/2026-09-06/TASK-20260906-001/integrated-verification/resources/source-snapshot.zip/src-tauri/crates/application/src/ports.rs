//! 应用层端口（依赖倒置边界）。
//!
//! 用例只面向这些 trait 编程，代理、仓储、证书和文件等具体实现由 Host 注入。测试可
//! 使用内存实现，TUI/CLI 也无需启动 Tauri 或 `WebView`。

use async_trait::async_trait;

mod android;
pub use android::AndroidControlPort;
mod application_bundle;
pub use application_bundle::ApplicationBundleReplacementPort;

mod external_packages;
pub use external_packages::ExternalPackageApplicationPort;

mod protocol_packages;
pub use protocol_packages::{
    BuiltinProtocolPackagePort, ProtocolPackageApplicationServices, ProtocolPackageImportPort,
    ProtocolPackageUsageQueryPort,
};

use crate::{
    ActiveFaultViewModel, AppResult, CaptureDetailViewModel, CapturePageViewModel, CaptureQuery,
    CertificateItemViewModel, CertificateOverviewViewModel, CertificateReference,
    CertificateValidationViewModel, ExchangeObservationPage, ExchangeObservationQuery,
    ExchangeObservationRecord, FaultConfigurationDraft, FaultTemplateViewModel,
    ListenerCertificateImportViewModel, ListenerId, ListenerStatusViewModel,
    ListenerUpstreamConnectionTestViewModel, ListenerUpstreamTlsTestViewModel,
    OperationResultViewModel, PortableCertificateMaterial, ProxyListener, ProxyWorkspace,
    RuleDefinition, RuleDefinitionSaveInput, RuntimeEpoch, SecretReference, SessionDetailViewModel,
    SessionId, SessionListViewModel, SessionQuery, SettingsDraft, SettingsValidationViewModel,
    SettingsViewModel, WorkspaceCollectionViewModel, WorkspaceId, WorkspaceSummaryViewModel,
    WorkspaceValidationViewModel,
};
/// Read-only access to the bounded in-process Exchange observation timeline.
///
/// Storage, retention, producer counters, and UI mutation ownership remain in an outer adapter;
/// presentation adapters query the same store only through this Application dependency port.
pub trait ExchangeObservationQueryPort: Send + Sync + std::fmt::Debug {
    fn query(&self, query: &ExchangeObservationQuery) -> ExchangeObservationPage;

    fn get(&self, exchange_id: &str) -> Option<ExchangeObservationRecord>;
}

#[async_trait]
/// Listener TLS 材料的原生导入边界。
///
/// 实现负责文件选择、格式校验与系统级保护；应用层和展示层只获得可安全写入
/// Workspace 的引用。`None` 表示用户取消选择。
pub trait ListenerCertificateImportPort: Send + Sync + std::fmt::Debug {
    async fn import_downstream_server_identity(
        &self,
        label: String,
        password: String,
    ) -> AppResult<Option<ListenerCertificateImportViewModel>>;

    async fn import_downstream_client_trust(
        &self,
        label: String,
    ) -> AppResult<Option<ListenerCertificateImportViewModel>>;

    async fn import_upstream_client_identity(
        &self,
        label: String,
        password: String,
    ) -> AppResult<Option<ListenerCertificateImportViewModel>>;

    async fn import_upstream_server_trust(
        &self,
        label: String,
    ) -> AppResult<Option<ListenerCertificateImportViewModel>>;

    /// 读取安全引用并只返回证书的公开元数据，不返回路径、密码、私钥或证书原始字节。
    async fn inspect(&self, reference: CertificateReference)
    -> AppResult<CertificateItemViewModel>;

    /// 将托管证书材料读取为单文件配置中的可移植载荷。
    ///
    /// 该方法只由用户主动导出配置时调用。运行时 Workspace 仍只保存安全引用，不会把
    /// 原始证书、私钥或密码写入 SQLite、事件或普通 DTO。
    async fn export_portable(
        &self,
        reference: CertificateReference,
    ) -> AppResult<PortableCertificateMaterial>;

    /// Fully parses and validates portable material without persisting secrets or references.
    async fn preflight_portable(&self, material: &PortableCertificateMaterial) -> AppResult<()>;

    /// Opaque digest of managed Listener certificate state for preview staleness checks.
    async fn application_backup_baseline(&self) -> AppResult<[u8; 32]>;

    /// 校验可移植载荷并写入当前机器的受保护存储，返回新的本机托管引用。
    async fn restore_portable(
        &self,
        material: PortableCertificateMaterial,
    ) -> AppResult<CertificateReference>;

    /// 删除尚未被任何 Workspace 引用的受保护证书材料。
    ///
    /// 应用层必须先完成全局引用检查；基础设施层仍需拒绝非托管引用并校验材料类型，
    /// 防止把该接口扩展成任意文件或任意密钥删除能力。
    async fn discard(&self, reference: CertificateReference) -> AppResult<()>;
}

#[async_trait]
/// 系统密钥保护下的秘密写入边界。
///
/// 展示层只提交本次输入的用户名和密码，并只拿回不可逆的安全引用。明文不会进入
/// Workspace、SQLite、事件、日志或返回 DTO；未来 CLI/TUI 复用同一用例即可。
pub trait ProtectedSecretPort: Send + Sync + std::fmt::Debug {
    async fn store_basic_auth(
        &self,
        username: String,
        password: String,
    ) -> AppResult<SecretReference>;
}

#[async_trait]
/// Workspace 的应用层持久化边界。
///
/// 仓储只处理领域模型及其本机安全引用。单文件证书载荷由应用门面通过证书端口恢复后，
/// 再把重写过引用的 Workspace 交给仓储持久化。
pub trait WorkspaceRepositoryPort: Send + Sync + std::fmt::Debug {
    /// 一次读取返回同一代 Workspace 的摘要和详情，避免调用者产生 N+1 查询或混合代快照。
    async fn snapshot(&self) -> AppResult<WorkspaceCollectionViewModel>;
    async fn list(&self) -> AppResult<Vec<WorkspaceSummaryViewModel>>;
    async fn get(&self, workspace_id: WorkspaceId) -> AppResult<ProxyWorkspace>;
    async fn create(&self, name: String) -> AppResult<ProxyWorkspace>;
    async fn copy(&self, workspace_id: WorkspaceId) -> AppResult<ProxyWorkspace>;
    async fn select(&self, workspace_id: WorkspaceId) -> AppResult<WorkspaceSummaryViewModel>;
    async fn validate(&self, workspace: ProxyWorkspace) -> AppResult<WorkspaceValidationViewModel>;
    async fn save(&self, workspace: ProxyWorkspace) -> AppResult<ProxyWorkspace>;
    /// 保存已由应用层完成证书恢复的可移植 Workspace，并重映射全部领域 ID。
    async fn import_workspace(&self, workspace: ProxyWorkspace) -> AppResult<ProxyWorkspace>;
    async fn delete(
        &self,
        workspace_id: WorkspaceId,
        expected_revision: u64,
    ) -> AppResult<OperationResultViewModel>;
}

#[async_trait]
/// 每个动态 Listener 的网络生命周期边界。
pub trait ListenerRuntimePort: Send + Sync + std::fmt::Debug {
    async fn statuses(&self) -> AppResult<Vec<ListenerStatusViewModel>>;
    /// 以 application 已校验的不可变 Workspace 快照启动入口。Infrastructure 可以在
    /// Scripted 启动边界从持久化规范文件 fresh 编译精确包；计划生成后不得再反查 `SQLite`
    /// 或依赖 UI 当前选择状态。Direct 分支也不得访问协议包注册表。
    async fn start(
        &self,
        workspace: ProxyWorkspace,
        listener: ProxyListener,
    ) -> AppResult<ListenerStatusViewModel>;
    async fn stop(&self, listener_id: ListenerId) -> AppResult<ListenerStatusViewModel>;
    /// 在 Listener 事务边界内持久化统一规则 CAS，并发布同一 revision 的运行快照。
    async fn replace_rule_definitions(
        &self,
        workspaces: &dyn WorkspaceRepositoryPort,
        workspace: ProxyWorkspace,
        listener_id: ListenerId,
    ) -> AppResult<ProxyWorkspace>;
    /// 使用固定 Server 的 scheme 执行 DNS/TCP 或 DNS/TCP/TLS 连接测试。
    async fn test_upstream_connection(
        &self,
        workspace: ProxyWorkspace,
        listener: ProxyListener,
    ) -> AppResult<ListenerUpstreamConnectionTestViewModel>;
    /// 使用该入口持久化的上游地址、CA、主机名校验和可选客户端身份执行真实握手。
    async fn test_upstream_tls(
        &self,
        workspace: ProxyWorkspace,
        listener: ProxyListener,
    ) -> AppResult<ListenerUpstreamTlsTestViewModel>;
}

#[async_trait]
/// 抓包列表与详情的只读数据端口。
pub trait CaptureRepositoryPort: Send + Sync + std::fmt::Debug {
    async fn query(&self, query: CaptureQuery) -> AppResult<CapturePageViewModel>;
    async fn get_detail(
        &self,
        session_id: SessionId,
        runtime_epoch: RuntimeEpoch,
    ) -> AppResult<CaptureDetailViewModel>;
    async fn clear_view(&self, current_cursor: u64) -> AppResult<u64>;
}

#[async_trait]
/// 将“故障模板”转换为普通规则并管理其生命周期的端口。
pub trait FaultServicePort: Send + Sync + std::fmt::Debug {
    async fn templates(&self) -> AppResult<Vec<FaultTemplateViewModel>>;
    async fn rule_draft(
        &self,
        draft: FaultConfigurationDraft,
    ) -> AppResult<RuleDefinitionSaveInput>;
    fn active_view(&self, rule: &RuleDefinition) -> Option<ActiveFaultViewModel>;
}

#[async_trait]
/// 证书生成、导入、导出与校验端口。
///
/// application 只处理用例顺序和错误，不接触私钥字节或平台密钥库。
pub trait CertificateServicePort: Send + Sync + std::fmt::Debug {
    /// 只读取非敏感元数据，用于应用启动状态栏和列表渲染。
    ///
    /// 这个调用不得解密私钥，也不得触发系统钥匙串授权；需要验证证书与私钥是否匹配时
    /// 必须显式调用 [`Self::overview`] 或 [`Self::validate`]。
    async fn status(&self) -> AppResult<CertificateOverviewViewModel>;
    /// 将持久化证书同步为产品策略要求的安装级信任链。
    ///
    /// 产品策略未提供固定 Root 时，首次同步为当前安装实例生成独立 Root 和叶子证书；
    /// 材料已经完整时必须保持幂等且不增加修订号。已撤销材料由基础设施层拒绝使用。
    async fn synchronize_installation_ca(
        &self,
        fallback_sans: Vec<String>,
    ) -> AppResult<CertificateOverviewViewModel>;
    async fn overview(&self) -> AppResult<CertificateOverviewViewModel>;
    async fn generate_ca(&self, sans: Vec<String>) -> AppResult<CertificateOverviewViewModel>;
    async fn export_ca(&self) -> AppResult<OperationResultViewModel>;
    async fn reissue_leaf(
        &self,
        expected_revision: u64,
        sans: Vec<String>,
    ) -> AppResult<CertificateOverviewViewModel>;
    async fn import_pkcs12(&self, password: String) -> AppResult<CertificateOverviewViewModel>;
    async fn import_upstream_ca(&self) -> AppResult<CertificateOverviewViewModel>;
    async fn validate(&self) -> AppResult<CertificateValidationViewModel>;
    async fn reset_ca(&self, expected_revision: u64) -> AppResult<CertificateOverviewViewModel>;
}

#[async_trait]
/// 保存和校验全局配置的端口。
pub trait SettingsRepositoryPort: Send + Sync + std::fmt::Debug {
    async fn defaults(&self) -> AppResult<SettingsDraft>;
    async fn get(&self) -> AppResult<SettingsViewModel>;
    async fn validate(&self, draft: &SettingsDraft) -> AppResult<SettingsValidationViewModel>;
    async fn save(&self, draft: SettingsDraft) -> AppResult<SettingsViewModel>;
}

#[async_trait]
/// 会话查询端口，负责 Rust 侧筛选和排序。
pub trait SessionQueryPort: Send + Sync + std::fmt::Debug {
    async fn query(&self, query: SessionQuery) -> AppResult<SessionListViewModel>;
    async fn get(&self, session_id: SessionId) -> AppResult<SessionDetailViewModel>;
    async fn clear_completed(&self) -> AppResult<usize>;
}
