import { defineConfig, globalIgnores } from "eslint/config";
import nextVitals from "eslint-config-next/core-web-vitals";
import nextTs from "eslint-config-next/typescript";

const eslintConfig = defineConfig([
  ...nextVitals,
  ...nextTs,
  // Override default ignores of eslint-config-next.
  globalIgnores([
    // Default ignores of eslint-config-next:
    ".next/**",
    "coverage/**",
    "out/**",
    "build/**",
    "next-env.d.ts",
    "src/generated/**",
    "docs/testing/evidence/**/resources/**",
    "src-tauri/target/**",
    "android-companion/**/build/**",
    "android-companion/.gradle/**",
    "android-companion/.kotlin/**",
  ]),
]);

export default eslintConfig;
