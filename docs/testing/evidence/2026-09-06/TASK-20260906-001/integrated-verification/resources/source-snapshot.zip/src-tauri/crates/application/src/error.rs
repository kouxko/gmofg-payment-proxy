//! 面向展示适配器的统一应用错误。
//!
//! 应用层把领域、存储、证书和网络错误整理成稳定错误码、中文说明、字段错误、重试
//! 建议和实体 ID。前端只展示，不应解析字符串猜测业务原因。

use std::collections::BTreeMap;

use serde::{Deserialize, Serialize};
use specta::Type;
use thiserror::Error;

use crate::RuntimeEpoch;

pub type AppResult<T> = Result<T, AppError>;

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize, Type)]
/// 可安全跨 IPC 展示的导入定位信息。
/// 所有字符串都必须在进入 Application 前完成校验：`file` 只能是包内相对路径，
/// `field` 只能是收敛后的声明字段路径，`entry` 只能是合法脚本函数标识。这里刻意没有
/// source、原始第三方错误文本或本机路径字段，避免诊断能力演变成源码泄漏通道。
pub struct AppErrorDiagnosticViewModel {
    pub file: Option<String>,
    pub field: Option<String>,
    pub line: Option<u32>,
    pub column: Option<u32>,
    pub entry: Option<String>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize, Type)]
pub struct AppErrorViewModel {
    pub code: String,
    pub message: String,
    pub field_errors: BTreeMap<String, Vec<String>>,
    pub retryable: bool,
    pub suggested_action: Option<String>,
    pub entity_id: Option<String>,
    pub runtime_epoch: Option<RuntimeEpoch>,
    pub diagnostic: Option<AppErrorDiagnosticViewModel>,
}

#[derive(Debug, Clone, PartialEq, Eq, Error)]
#[error("{view_model:?}")]
pub struct AppError {
    pub view_model: Box<AppErrorViewModel>,
}

impl AppError {
    pub fn new(code: impl Into<String>, message: impl Into<String>) -> Self {
        Self {
            view_model: Box::new(AppErrorViewModel {
                code: code.into(),
                message: message.into(),
                field_errors: BTreeMap::new(),
                retryable: false,
                suggested_action: None,
                entity_id: None,
                runtime_epoch: None,
                diagnostic: None,
            }),
        }
    }

    pub fn field(
        code: impl Into<String>,
        message: impl Into<String>,
        field_errors: BTreeMap<String, Vec<String>>,
    ) -> Self {
        let mut error = Self::new(code, message);
        error.view_model.field_errors = field_errors;
        error
    }

    #[must_use]
    pub fn retryable(mut self, suggested_action: impl Into<String>) -> Self {
        self.view_model.retryable = true;
        self.view_model.suggested_action = Some(suggested_action.into());
        self
    }

    #[must_use]
    pub fn entity(mut self, entity_id: impl Into<String>) -> Self {
        self.view_model.entity_id = Some(entity_id.into());
        self
    }

    #[must_use]
    pub fn epoch(mut self, runtime_epoch: RuntimeEpoch) -> Self {
        self.view_model.runtime_epoch = Some(runtime_epoch);
        self
    }

    #[must_use]
    pub fn runtime_context(
        mut self,
        entity_id: impl Into<String>,
        runtime_epoch: Option<RuntimeEpoch>,
    ) -> Self {
        self.view_model.entity_id = Some(entity_id.into());
        self.view_model.runtime_epoch = runtime_epoch;
        self
    }

    #[must_use]
    pub fn diagnostic(mut self, diagnostic: AppErrorDiagnosticViewModel) -> Self {
        self.view_model.diagnostic = Some(diagnostic);
        self
    }
}

impl From<AppError> for AppErrorViewModel {
    fn from(value: AppError) -> Self {
        *value.view_model
    }
}

impl From<intercept_proxy_domain::DomainError> for AppError {
    fn from(value: intercept_proxy_domain::DomainError) -> Self {
        Self {
            view_model: Box::new(AppErrorViewModel {
                code: value.code.as_str().to_owned(),
                message: value.message,
                field_errors: *value.field_errors,
                retryable: value.retryable,
                suggested_action: value.suggested_action,
                entity_id: value.entity_id,
                runtime_epoch: value
                    .runtime_epoch
                    .map(intercept_proxy_domain::RuntimeEpoch::as_uuid),
                diagnostic: None,
            }),
        }
    }
}
