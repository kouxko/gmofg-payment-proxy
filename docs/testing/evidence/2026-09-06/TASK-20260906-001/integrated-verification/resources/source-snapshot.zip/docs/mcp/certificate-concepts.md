# 证书概念与排查指南

这份说明面向第一次接触 HTTPS、TLS 和双向认证的使用者。Intercept Proxy 的 MCP
只能读取证书状态、公开证书信息和诊断记录，不会返回私钥、密码或原始 PKCS#12
内容，也不会替你导入、删除或更换证书。

## 先理解两段连接

代理位于应用和远端服务之间，因此 HTTPS 会拆成两段：

1. **应用 → 代理**：代理要向应用证明“我是你要访问的服务”。
2. **代理 → 远端服务**：远端服务要向代理证明“我是正确的服务”。

这两段连接分别验证，第一段成功不代表第二段也一定成功。

## 常见证书分别是什么

- **Root CA（根证书）**：签发其他证书的信任起点。应用或设备只有信任代理的
  Root CA，才会接受代理动态签发的服务端证书。
- **服务端证书**：服务端在 TLS 握手时出示的身份证明。证书中的主机名必须与实际
  访问的主机名匹配。
- **客户端证书**：某些服务要求连接方也出示身份证明，这叫双向 TLS（mTLS）。此时
  代理连接上游服务时需要客户端证书和对应私钥。
- **私钥**：证明证书确实属于持有者的秘密材料。私钥不能公开，也不能只拿证书文件
  代替。
- **PEM**：文本形式的证书或私钥容器，文件中可能包含一张或多张证书，也可能包含
  私钥。
- **PKCS#12 / P12 / PFX**：通常把证书链和私钥放在同一个二进制文件中，可能需要
  密码解密。

## 在 Intercept Proxy 中如何对应

- **App 接入证书**：用于“应用 → 代理”。应用需要信任对应 Root CA；启用 mTLS 时，
  代理还会验证应用提供的客户端证书。
- **Server 上游信任**：用于“代理 → 远端服务”。代理检查远端服务证书、主机名、
  有效期和签发链。
- **上游客户端身份**：远端服务要求 mTLS 时，代理用它向远端服务证明身份。

### 上游缺少 Intermediate CA 时

如果远端 Server 没有发送完整证书链，可以把 Intermediate CA 和 Root CA 合并为一个 PEM
Bundle，再通过现有的单文件 Server Trust 入口导入。Proxy 会加载 Bundle 中的全部证书；
它不会执行 Shell、写文件、替你合并多个文件或关闭 hostname/证书链校验。

```bash
{
  openssl x509 -in intermediate.pem -outform PEM
  openssl x509 -in root.pem -outform PEM
} > upstream-trust-chain.pem
```

查看 Bundle 中的证书：

```bash
openssl crl2pkcs7 -nocrl -certfile upstream-trust-chain.pem |
  openssl pkcs7 -print_certs -noout
```

先验证 Intermediate，再验证目标 TLS：

```bash
openssl verify -CAfile root.pem intermediate.pem
openssl s_client -connect server.example:443 \
  -servername server.example \
  -CAfile upstream-trust-chain.pem \
  -showcerts -verify_return_error
```

## 常见错误怎么理解

- **Trust anchor not found / 未找到信任根**：应用或设备不信任签发当前服务端证书的
  Root CA。先确认 Root CA 是否安装，以及应用是否允许信任用户证书。
- **Hostname mismatch / 主机名不匹配**：证书中的 DNS 名称或 IP 与实际访问地址不同。
- **Certificate expired / 证书过期**：检查证书有效期和设备时间。
- **Client certificate required / 需要客户端证书**：远端启用了 mTLS，但代理没有配置
  可用的上游客户端身份，或证书链不被远端信任。
- **Private key mismatch / 私钥不匹配**：证书和私钥不是同一对材料。

## 向 AI 提问时建议提供什么

可以让 AI 通过 MCP 读取证书概览、入口状态和最近诊断，然后询问：

- “为什么应用不信任代理证书？”
- “是应用到代理失败，还是代理到上游失败？”
- “这个入口是否要求客户端证书？”
- “最近一次 TLS 失败应该先检查哪一项？”

不要把私钥、证书密码、PIN、真实支付敏感数据复制到聊天中。
