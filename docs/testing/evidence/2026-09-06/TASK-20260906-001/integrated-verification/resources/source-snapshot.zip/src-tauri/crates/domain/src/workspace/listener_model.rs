//! Listener 公共配置与互斥的数据平面配置。

use serde::{Deserialize, Deserializer, Serialize};
use specta::Type;

use crate::{CertificateReferenceId, ListenerId, ProtocolPackageRef};

use super::{DEFAULT_FORWARD_PROXY_PORT, SocketRelaySettings};

mod socket;

pub use socket::*;

pub const DEFAULT_SOCKET_MAXIMUM_CONNECTIONS: u16 = 500;
pub const MAX_SOCKET_MAXIMUM_CONNECTIONS: u16 = 5_000;

#[derive(Clone, Copy, Debug, Default, Deserialize, Eq, PartialEq, Serialize, Type)]
#[serde(rename_all = "snake_case")]
pub enum BodyCodecKind {
    #[default]
    Auto,
    Raw,
    Utf8,
    ShiftJis,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize, Type)]
#[serde(deny_unknown_fields)]
pub struct SecretReference {
    pub provider: String,
    pub key: String,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Type)]
#[serde(tag = "mode", rename_all = "snake_case")]
pub enum ForwardProxyAuthentication {
    None,
    Basic { credential: SecretReference },
}

impl<'de> Deserialize<'de> for ForwardProxyAuthentication {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        #[derive(Deserialize)]
        #[serde(tag = "mode", rename_all = "snake_case", deny_unknown_fields)]
        enum Wire {
            None {},
            Basic { credential: SecretReference },
        }
        Ok(match Wire::deserialize(deserializer)? {
            Wire::None {} => Self::None,
            Wire::Basic { credential } => Self::Basic { credential },
        })
    }
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize, Type)]
#[serde(deny_unknown_fields)]
pub struct MitmSettings {
    pub enabled: bool,
    pub authority_allowlist: Vec<String>,
    pub root_ca: Option<CertificateReferenceId>,
    pub maximum_cached_leaf_certificates: u16,
}

impl Default for MitmSettings {
    fn default() -> Self {
        Self {
            enabled: false,
            authority_allowlist: Vec::new(),
            root_ca: None,
            maximum_cached_leaf_certificates: 256,
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Type)]
#[serde(tag = "mode", rename_all = "snake_case")]
pub enum DownstreamClientAuthentication {
    Disabled,
    Optional { trust: CertificateReferenceId },
    Required { trust: CertificateReferenceId },
}

impl<'de> Deserialize<'de> for DownstreamClientAuthentication {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        #[derive(Deserialize)]
        #[serde(tag = "mode", rename_all = "snake_case", deny_unknown_fields)]
        enum Wire {
            Disabled {},
            Optional { trust: CertificateReferenceId },
            Required { trust: CertificateReferenceId },
        }
        Ok(match Wire::deserialize(deserializer)? {
            Wire::Disabled {} => Self::Disabled,
            Wire::Optional { trust } => Self::Optional { trust },
            Wire::Required { trust } => Self::Required { trust },
        })
    }
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize, Type)]
#[serde(deny_unknown_fields)]
pub struct DownstreamTlsSettings {
    pub enabled: bool,
    pub server_identity: Option<CertificateReferenceId>,
    pub dynamic_sni_allowlist: Vec<String>,
    pub client_authentication: DownstreamClientAuthentication,
}

impl Default for DownstreamTlsSettings {
    fn default() -> Self {
        Self {
            enabled: false,
            server_identity: None,
            dynamic_sni_allowlist: Vec::new(),
            client_authentication: DownstreamClientAuthentication::Disabled,
        }
    }
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize, Type)]
#[serde(deny_unknown_fields)]
pub struct UpstreamTlsSettings {
    pub verify_hostname: bool,
    pub server_trust: Option<CertificateReferenceId>,
    pub client_identity: Option<CertificateReferenceId>,
}

impl Default for UpstreamTlsSettings {
    fn default() -> Self {
        Self {
            verify_hostname: true,
            server_trust: None,
            client_identity: None,
        }
    }
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize, Type)]
#[serde(deny_unknown_fields)]
pub struct FixedServerSettings {
    pub upstream_url: String,
    pub upstream_tls: UpstreamTlsSettings,
}

#[derive(Clone, Debug, Default, Deserialize, Eq, PartialEq, Serialize, Type)]
#[serde(deny_unknown_fields)]
pub struct HttpRemoteServerTopology {
    pub fixed_server: Option<FixedServerSettings>,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize, Type)]
#[serde(
    tag = "mode",
    content = "settings",
    rename_all = "snake_case",
    deny_unknown_fields
)]
pub enum HttpTopology {
    RemoteServer(HttpRemoteServerTopology),
    LocalServer,
}

impl Default for HttpTopology {
    fn default() -> Self {
        Self::RemoteServer(HttpRemoteServerTopology::default())
    }
}

impl HttpTopology {
    #[must_use]
    pub fn remote(fixed_server: Option<FixedServerSettings>) -> Self {
        Self::RemoteServer(HttpRemoteServerTopology { fixed_server })
    }
}

/// HTTP Body 的处理方式。
///
/// `Plain` 保持现有 HTTP 语义；`Protocol` 使用精确协议包版本把 UTF-8 Body 解码为
/// Document，并在 Document 实际变化时重新编码。未命中规则时不会重写 Body。
#[derive(Clone, Debug, Default, Deserialize, Eq, PartialEq, Serialize, Type)]
#[serde(tag = "mode", rename_all = "snake_case")]
pub enum HttpBodyProcessing {
    #[default]
    Plain,
    Protocol {
        package: ProtocolPackageRef,
    },
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Type)]
pub struct HttpListenerSettings {
    pub authentication: ForwardProxyAuthentication,
    pub mitm: MitmSettings,
    pub downstream_tls: DownstreamTlsSettings,
    pub request_body_codec: BodyCodecKind,
    pub response_body_codec: BodyCodecKind,
    pub body_processing: HttpBodyProcessing,
    pub topology: HttpTopology,
}

impl Default for HttpListenerSettings {
    fn default() -> Self {
        Self {
            authentication: ForwardProxyAuthentication::None,
            mitm: MitmSettings::default(),
            downstream_tls: DownstreamTlsSettings::default(),
            request_body_codec: BodyCodecKind::Auto,
            response_body_codec: BodyCodecKind::Auto,
            body_processing: HttpBodyProcessing::Plain,
            topology: HttpTopology::default(),
        }
    }
}

impl HttpListenerSettings {
    #[must_use]
    pub const fn remote_server(&self) -> Option<&HttpRemoteServerTopology> {
        match &self.topology {
            HttpTopology::RemoteServer(remote) => Some(remote),
            HttpTopology::LocalServer => None,
        }
    }

    #[must_use]
    pub const fn remote_server_mut(&mut self) -> Option<&mut HttpRemoteServerTopology> {
        match &mut self.topology {
            HttpTopology::RemoteServer(remote) => Some(remote),
            HttpTopology::LocalServer => None,
        }
    }

    #[must_use]
    pub fn fixed_server(&self) -> Option<&FixedServerSettings> {
        self.remote_server()
            .and_then(|remote| remote.fixed_server.as_ref())
    }

    #[must_use]
    pub fn uses_request_target(&self) -> bool {
        self.remote_server()
            .is_some_and(|remote| remote.fixed_server.is_none())
    }
}

impl<'de> Deserialize<'de> for HttpListenerSettings {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        #[derive(Default)]
        struct LegacyFixedServer {
            present: bool,
            value: Option<FixedServerSettings>,
        }

        impl<'de> Deserialize<'de> for LegacyFixedServer {
            fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
            where
                D: Deserializer<'de>,
            {
                Ok(Self {
                    present: true,
                    value: Option::<FixedServerSettings>::deserialize(deserializer)?,
                })
            }
        }

        #[derive(Deserialize)]
        #[serde(deny_unknown_fields)]
        struct Wire {
            authentication: ForwardProxyAuthentication,
            mitm: MitmSettings,
            downstream_tls: DownstreamTlsSettings,
            request_body_codec: BodyCodecKind,
            response_body_codec: BodyCodecKind,
            body_processing: HttpBodyProcessing,
            #[serde(default)]
            topology: Option<HttpTopology>,
            #[serde(default)]
            fixed_server: LegacyFixedServer,
        }

        let wire = Wire::deserialize(deserializer)?;
        if wire.topology.is_some() && wire.fixed_server.present {
            return Err(serde::de::Error::custom(
                "HTTP topology and legacy fixed_server cannot be configured together",
            ));
        }
        Ok(Self {
            authentication: wire.authentication,
            mitm: wire.mitm,
            downstream_tls: wire.downstream_tls,
            request_body_codec: wire.request_body_codec,
            response_body_codec: wire.response_body_codec,
            body_processing: wire.body_processing,
            topology: wire.topology.unwrap_or({
                HttpTopology::RemoteServer(HttpRemoteServerTopology {
                    fixed_server: wire.fixed_server.value,
                })
            }),
        })
    }
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize, Type)]
#[serde(
    tag = "kind",
    content = "settings",
    rename_all = "snake_case",
    deny_unknown_fields
)]
pub enum ListenerDataPlane {
    Http(HttpListenerSettings),
    Socket(SocketRelaySettings),
}

impl Default for ListenerDataPlane {
    fn default() -> Self {
        Self::Http(HttpListenerSettings::default())
    }
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize, Type)]
#[serde(deny_unknown_fields)]
pub struct ProxyListener {
    pub id: ListenerId,
    pub name: String,
    pub enabled: bool,
    pub bind_address: String,
    pub port: u16,
    pub connect_timeout_ms: u64,
    pub read_timeout_ms: u64,
    pub write_timeout_ms: u64,
    pub data_plane: ListenerDataPlane,
}

impl Default for ProxyListener {
    fn default() -> Self {
        Self {
            id: ListenerId::new(),
            name: "默认代理监听".into(),
            enabled: false,
            bind_address: "127.0.0.1".into(),
            port: DEFAULT_FORWARD_PROXY_PORT,
            connect_timeout_ms: 30_000,
            read_timeout_ms: 70_000,
            write_timeout_ms: 70_000,
            data_plane: ListenerDataPlane::default(),
        }
    }
}

impl ProxyListener {
    #[must_use]
    pub const fn id(&self) -> ListenerId {
        self.id
    }

    #[must_use]
    pub const fn enabled(&self) -> bool {
        self.enabled
    }

    #[must_use]
    pub fn bind_endpoint(&self) -> (&str, u16) {
        (&self.bind_address, self.port)
    }

    #[must_use]
    pub const fn http(&self) -> Option<&HttpListenerSettings> {
        match &self.data_plane {
            ListenerDataPlane::Http(settings) => Some(settings),
            ListenerDataPlane::Socket(_) => None,
        }
    }

    #[must_use]
    pub const fn http_mut(&mut self) -> Option<&mut HttpListenerSettings> {
        match &mut self.data_plane {
            ListenerDataPlane::Http(settings) => Some(settings),
            ListenerDataPlane::Socket(_) => None,
        }
    }

    #[must_use]
    pub const fn socket(&self) -> Option<&SocketRelaySettings> {
        match &self.data_plane {
            ListenerDataPlane::Http(_) => None,
            ListenerDataPlane::Socket(settings) => Some(settings),
        }
    }
}
