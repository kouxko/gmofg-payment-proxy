// @vitest-environment jsdom
import "@testing-library/jest-dom/vitest";
import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { bootstrap, setupListenerMocks, mocks, workspace, dynamicListener, fixedListener, socketListener, localResponderListener, ok, commandError, listenerStatus, listenerOverview, navigationMocks } from "./listeners-view.test-support";

vi.mock("@/features/shell/workspace-navigation", () => ({
  useWorkspaceNavigation: () => navigationMocks,
  useWorkspaceQueryInvalidation: vi.fn(),
}));
vi.mock("@/features/shell/bootstrap-context", () => ({
  useAppEventRefresh: () => undefined,
  useBootstrap: () => ({ bootstrap }),
}));
vi.mock("@/features/shell/selected-workspace-context", () => ({ useSelectedWorkspace: () => ({ selected: { id: "workspace-1", revision: 1 }, summaries: [], isLoading: false, refresh: vi.fn() }) }));
vi.mock("@/generated/rust-types", () => ({ commands: mocks }));
import { ListenersView } from "./listeners-view";
describe("统一代理监听编辑器", () => {
  beforeEach(setupListenerMocks);

  it("只提供一个新建入口并调用无参数 Rust command", async () => {
    const user = userEvent.setup();
    render(<ListenersView />);
    expect(await screen.findByRole("button", { name: "新建代理监听" })).toBeVisible();
    expect(screen.queryByRole("button", { name: /新增正向|新增转发/ })).not.toBeInTheDocument();
    await user.click(screen.getByRole("button", { name: "新建代理监听" }));
    expect(mocks.listenerNew).toHaveBeenCalledWith();
    expect(await screen.findByRole("textbox", { name: "代理监听名称" })).toHaveValue("新建代理监听");
  });

  it("未保存的新建或复制监听无需 Rust runtime capability 即可本地丢弃", async () => {
    const user = userEvent.setup();
    render(<ListenersView />);

    await user.click(await screen.findByRole("button", { name: "新建代理监听" }));
    const deleteButton = screen.getByRole("button", { name: "删除监听" });
    expect(deleteButton).toBeEnabled();
    await user.click(deleteButton);

    expect(await screen.findByRole("textbox", { name: "代理监听名称" })).toHaveValue("默认代理监听");
    await user.click(screen.getByRole("button", { name: "复制监听" }));
    expect(await screen.findByRole("textbox", { name: "代理监听名称" })).toHaveValue("默认代理监听 副本");
    await user.click(screen.getByRole("button", { name: "删除监听" }));

    expect(await screen.findByRole("textbox", { name: "代理监听名称" })).toHaveValue("默认代理监听");
    expect(mocks.listenerDelete).not.toHaveBeenCalled();
  });

  it("使用与 Socket 一致的响应方式下拉切换并保存 HTTP topology", async () => {
    const fixed = fixedListener("listener-1", "默认代理监听", 8080, "");
    const local = {
      ...fixed,
      data_plane: { kind: "http" as const, settings: {
        ...fixed.data_plane.settings,
        topology: { mode: "local_server" as const },
      } },
    };
    mocks.listenerDraftTransition
      .mockReturnValueOnce(ok(fixed))
      .mockReturnValueOnce(ok(local))
      .mockReturnValueOnce(ok(dynamicListener()));
    const user = userEvent.setup();
    render(<ListenersView />);

    const responseMode = await screen.findByLabelText("HTTP 响应方式");
    expect(responseMode).toHaveTextContent("按原请求目标转发");
    expect(screen.queryByRole("switch", { name: "使用 Local HTTP Server" })).not.toBeInTheDocument();
    expect(screen.queryByRole("switch", { name: "转发到固定 Server" })).not.toBeInTheDocument();
    await user.click(responseMode);
    await user.click(await screen.findByRole("option", { name: "转发到固定 Server" }));
    expect(responseMode).toHaveTextContent("转发到固定 Server");
    expect(screen.getByRole("textbox", { name: "固定 Server URL" })).toBeVisible();

    await user.click(responseMode);
    await user.click(await screen.findByRole("option", { name: "本机应答" }));
    expect(responseMode).toHaveTextContent("本机应答");
    expect(screen.queryByRole("switch", { name: "转发到固定 Server" })).not.toBeInTheDocument();
    expect(screen.queryByRole("textbox", { name: "固定 Server URL" })).not.toBeInTheDocument();

    await user.click(screen.getByRole("button", { name: "保存当前监听" }));
    await waitFor(() => expect(mocks.listenerSave).toHaveBeenCalledTimes(1));
    expect(mocks.listenerSave.mock.calls[0][2].data_plane).toMatchObject({
      kind: "http",
      settings: { topology: { mode: "local_server" } },
    });

    await user.click(responseMode);
    await user.click(await screen.findByRole("option", { name: "按原请求目标转发" }));
    expect(responseMode).toHaveTextContent("按原请求目标转发");
    expect(screen.queryByRole("switch", { name: "转发到固定 Server" })).not.toBeInTheDocument();
  });

  it("由 Rust 校验后保存统一监听", async () => {
    const user = userEvent.setup();
    render(<ListenersView />);
    const name = await screen.findByRole("textbox", { name: "代理监听名称" });
    await user.clear(name); await user.type(name, "本地代理");
    await user.click(screen.getByRole("button", { name: "保存当前监听" }));
    await waitFor(() => expect(mocks.listenerSave).toHaveBeenCalledTimes(1));
    expect(mocks.listenerSave.mock.calls[0][2].name).toBe("本地代理");
  });

  it("配置未修改时可在其他监听运行中直接启动第二个监听", async () => {
    const multiple = { ...workspace, listeners: [
      dynamicListener("running-1", "已运行监听", 8080),
      dynamicListener("stopped-2", "待启动监听", 8081),
    ] };
    mocks.workspaceGet.mockReturnValue(ok(multiple));
    mocks.listenerOverview.mockReturnValue(ok(listenerOverview([listenerStatus("running-1", "running"), listenerStatus("stopped-2")])));
    const user = userEvent.setup(); render(<ListenersView />);

    await user.click(await screen.findByText("待启动监听"));
    await user.click(screen.getByRole("button", { name: "启动监听" }));

    await waitFor(() => expect(mocks.listenerStart).toHaveBeenCalledWith("workspace-1", 1, "stopped-2"));
    expect(mocks.listenerDraftValidate).not.toHaveBeenCalled();
    expect(mocks.listenerSave).not.toHaveBeenCalled();
  });

  it("其他监听运行时仍保存当前脏草稿并启动", async () => {
    const multiple = { ...workspace, listeners: [
      dynamicListener("running-1", "已运行监听", 8080),
      dynamicListener("stopped-2", "待启动监听", 8081),
    ] };
    mocks.workspaceGet.mockReturnValue(ok(multiple));
    mocks.listenerOverview.mockReturnValue(ok(listenerOverview([listenerStatus("running-1", "running"), listenerStatus("stopped-2")])));
    const user = userEvent.setup(); render(<ListenersView />);

    await user.click(await screen.findByText("待启动监听"));
    const name = screen.getByRole("textbox", { name: "代理监听名称" });
    await user.clear(name); await user.type(name, "修改后的监听");
    await user.click(screen.getByRole("button", { name: "启动监听" }));

    await waitFor(() => expect(mocks.listenerSave).toHaveBeenCalledTimes(1));
    expect(mocks.listenerSave.mock.calls[0][2].name).toBe("修改后的监听");
    expect(mocks.listenerStart).toHaveBeenCalledWith("workspace-1", 2, "stopped-2");
  });

  it("启动 B 时保留 A 的未保存草稿", async () => {
    const listenerA = dynamicListener("listener-a", "监听 A", 8080);
    const listenerB = dynamicListener("listener-b", "监听 B", 8081);
    const multiple = { ...workspace, listeners: [listenerA, listenerB] };
    const afterSave = { ...multiple, revision: 2 };
    const afterStart = {
      ...multiple,
      revision: 3,
      listeners: [listenerA, { ...listenerB, enabled: true }],
    };
    mocks.workspaceGet
      .mockReturnValueOnce(ok(multiple))
      .mockReturnValue(ok(afterStart));
    mocks.listenerOverview.mockReturnValue(ok(listenerOverview([
      listenerStatus("listener-a"),
      listenerStatus("listener-b"),
    ])));
    mocks.listenerDraftValidate.mockImplementation((_workspaceId, revision, listener, certificateReferences) => ok({
      valid: true,
      normalized: {
        ...multiple,
        revision,
        listeners: multiple.listeners.map((item) => item.id === listener.id ? listener : item),
        certificate_references: certificateReferences,
      },
      field_errors: {},
    }));
    mocks.listenerSave.mockReturnValue(ok(afterSave));
    const user = userEvent.setup();
    render(<ListenersView />);

    const name = await screen.findByRole("textbox", { name: "代理监听名称" });
    await user.clear(name);
    await user.type(name, "监听 A 未保存名称");
    await user.click(screen.getByText("监听 B"));
    await user.click(screen.getByRole("button", { name: "启动监听" }));

    await waitFor(() => expect(mocks.listenerStart).toHaveBeenCalledWith(
      "workspace-1",
      2,
      "listener-b",
    ));
    await user.click(screen.getByText("监听 A 未保存名称"));
    expect(screen.getByRole("textbox", { name: "代理监听名称" })).toHaveValue("监听 A 未保存名称");
  });

  it("保存 B 时保留新建 A 及其未保存托管证书引用", async () => {
    const listenerB = dynamicListener("listener-b", "监听 B", 8080);
    const persisted = { ...workspace, listeners: [listenerB] };
    mocks.workspaceGet.mockReturnValue(ok(persisted));
    mocks.listenerOverview.mockReturnValue(ok(listenerOverview([listenerStatus("listener-b")] )));
    mocks.listenerDraftValidate.mockImplementation((_workspaceId, revision, listener, certificateReferences) => ok({
      valid: true,
      normalized: {
        ...persisted,
        revision,
        listeners: persisted.listeners.map((item) => item.id === listener.id ? listener : item),
        certificate_references: certificateReferences,
      },
      field_errors: {},
    }));
    mocks.listenerSave.mockImplementation((_workspaceId, _revision, listener, certificateReferences) => ok({
      ...persisted,
      revision: 2,
      listeners: [listener],
      certificate_references: certificateReferences,
    }));
    mocks.listenerDraftTransition.mockReturnValueOnce(ok(
      fixedListener("listener-new", "新建代理监听", 8081, ""),
    ));
    const user = userEvent.setup();
    render(<ListenersView />);

    await user.click(await screen.findByRole("button", { name: "新建代理监听" }));
    await user.click(screen.getByLabelText("HTTP 响应方式"));
    await user.click(await screen.findByRole("option", { name: "转发到固定 Server" }));
    await user.type(
      screen.getByRole("textbox", { name: "固定 Server URL" }),
      "https://server.test:443",
    );
    await user.click(screen.getByRole("button", { name: "导入 Server CA" }));
    await user.click(screen.getByRole("button", { name: "选择 CA 证书（.cer / .crt / .pem / .der）" }));
    await user.click(screen.getByText("监听 B"));
    await user.click(screen.getByRole("button", { name: "保存当前监听" }));

    await waitFor(() => expect(mocks.listenerSave).toHaveBeenCalledTimes(1));
    await user.click(screen.getByRole("row", { name: /新建代理监听/ }));
    expect(await screen.findByText("CN=测试上游 CA")).toBeVisible();
    expect(mocks.listenerCertificateDiscard).not.toHaveBeenCalled();
  });

  it("其他监听运行时仍可删除当前已停止监听", async () => {
    const multiple = { ...workspace, listeners: [
      dynamicListener("running-1", "已运行监听", 8080),
      dynamicListener("stopped-2", "待删除监听", 8081),
    ] };
    const afterDelete = { ...multiple, revision: 2, listeners: [multiple.listeners[0]] };
    mocks.workspaceGet
      .mockReturnValueOnce(ok(multiple))
      .mockReturnValue(ok(afterDelete));
    mocks.listenerOverview.mockReturnValue(ok(listenerOverview([
      listenerStatus("running-1", "running"),
      listenerStatus("stopped-2"),
    ])));
    const user = userEvent.setup(); render(<ListenersView />);

    await user.click(await screen.findByText("待删除监听"));
    await user.click(screen.getByRole("button", { name: "删除监听" }));

    await waitFor(() => expect(mocks.listenerDelete).toHaveBeenCalledWith(
      "workspace-1",
      1,
      "stopped-2",
    ));
    expect(mocks.workspaceSave).not.toHaveBeenCalled();
  });

  it("删除 B 时保留 A 的脏草稿和未保存托管证书引用", async () => {
    const listenerA = fixedListener("listener-a", "监听 A", 16627, "https://a.test:16627");
    const listenerB = dynamicListener("listener-b", "监听 B", 16127);
    const multiple = { ...workspace, listeners: [listenerA, listenerB] };
    const afterDelete = { ...multiple, revision: 2, listeners: [listenerA] };
    mocks.workspaceGet
      .mockReturnValueOnce(ok(multiple))
      .mockReturnValue(ok(afterDelete));
    mocks.listenerOverview.mockReturnValue(ok(listenerOverview([
      listenerStatus("listener-a"),
      listenerStatus("listener-b"),
    ])));
    const user = userEvent.setup();
    render(<ListenersView />);

    const name = await screen.findByRole("textbox", { name: "代理监听名称" });
    await user.clear(name);
    await user.type(name, "监听 A 未保存名称");
    await user.click(screen.getByRole("button", { name: "导入 Server CA" }));
    await user.click(screen.getByRole("button", { name: "选择 CA 证书（.cer / .crt / .pem / .der）" }));
    await user.click(screen.getByText("监听 B"));
    await user.click(screen.getByRole("button", { name: "删除监听" }));

    expect(await screen.findByRole("textbox", { name: "代理监听名称" })).toHaveValue("监听 A 未保存名称");
    expect(screen.getByText("CN=测试上游 CA")).toBeVisible();
    expect(mocks.listenerCertificateDiscard).not.toHaveBeenCalled();
  });

  it("运行概览查询失败时显式报错且禁止启动", async () => {
    mocks.listenerOverview.mockReturnValue(commandError("无法读取 Listener 运行概览。"));
    render(<ListenersView />);

    expect(await screen.findByText("运行状态：查询失败")).toBeVisible();
    expect(screen.getByText("无法读取 Listener 运行概览。")).toBeVisible();
    expect(screen.getByRole("button", { name: "状态不可用" })).toBeDisabled();
    expect(screen.getByRole("button", { name: "重试状态查询" })).toBeVisible();
  });

  it("Rust 概览缺少当前 Listener 行时显示未知且禁止启动", async () => {
    mocks.listenerOverview.mockReturnValue(ok(listenerOverview([])));
    render(<ListenersView />);

    expect(await screen.findByText("运行状态：未知（当前监听状态不可用）")).toBeVisible();
    expect(screen.getByRole("button", { name: "状态不可用" })).toBeDisabled();
    expect(mocks.listenerStart).not.toHaveBeenCalled();
  });

  it("故障 Listener 按 Rust capability 执行停止以释放 runtime ownership", async () => {
    mocks.listenerOverview.mockReturnValue(ok(listenerOverview([
      listenerStatus("listener-1", "faulted", { canStart: false, canStop: true }),
    ])));
    const user = userEvent.setup();
    render(<ListenersView />);

    expect(await screen.findByText("运行状态：故障")).toBeVisible();
    expect(screen.getByRole("button", { name: "删除监听" })).toBeDisabled();
    await user.click(screen.getByRole("button", { name: "停止监听" }));

    await waitFor(() => expect(mocks.listenerStop).toHaveBeenCalledWith(
      "workspace-1",
      1,
      "listener-1",
    ));
    expect(mocks.listenerStart).not.toHaveBeenCalled();
  });

  it("Rust 未授予启停 capability 时不推断启动但仍允许删除已确认 stopped 的配置", async () => {
    mocks.listenerOverview.mockReturnValue(ok(listenerOverview([
      listenerStatus("listener-1", "stopped", { canStart: false, canStop: false }),
    ])));
    render(<ListenersView />);

    expect(await screen.findByRole("button", { name: "无可用操作" })).toBeDisabled();
    expect(screen.getByRole("button", { name: "删除监听" })).toBeEnabled();
    expect(mocks.listenerStart).not.toHaveBeenCalled();
    expect(mocks.listenerStop).not.toHaveBeenCalled();
  });

  it("修改后恢复为持久化值时视为无未保存差异", async () => {
    const multiple = { ...workspace, listeners: [
      dynamicListener("running-1", "已运行监听", 8080),
      dynamicListener("stopped-2", "待启动监听", 8081),
    ] };
    mocks.workspaceGet.mockReturnValue(ok(multiple));
    mocks.listenerOverview.mockReturnValue(ok(listenerOverview([listenerStatus("running-1", "running"), listenerStatus("stopped-2")])));
    const user = userEvent.setup(); render(<ListenersView />);

    await user.click(await screen.findByText("待启动监听"));
    const name = screen.getByRole("textbox", { name: "代理监听名称" });
    await user.clear(name); await user.type(name, "临时名称");
    await user.clear(name); await user.type(name, "待启动监听");
    await user.click(screen.getByRole("button", { name: "启动监听" }));

    await waitFor(() => expect(mocks.listenerStart).toHaveBeenCalledWith("workspace-1", 1, "stopped-2"));
    expect(mocks.listenerSave).not.toHaveBeenCalled();
  });

  it("没有其他运行监听时仍先保存脏草稿再启动", async () => {
    const user = userEvent.setup(); render(<ListenersView />);
    const name = await screen.findByRole("textbox", { name: "代理监听名称" });
    await user.clear(name); await user.type(name, "修改后的监听");
    await user.click(screen.getByRole("button", { name: "启动监听" }));

    await waitFor(() => expect(mocks.listenerSave).toHaveBeenCalledTimes(1));
    expect(mocks.listenerStart).toHaveBeenCalledWith("workspace-1", 2, "listener-1");
  });

  it("保存 Socket 时只提交 active variant，不泄漏隐藏的 HTTP 或 TLS 字段", async () => {
    const socket = socketListener("socket-1", "Socket", 9000, "transparent");
    mocks.workspaceGet.mockReturnValue(ok({ ...workspace, listeners: [socket] }));
    mocks.listenerOverview.mockReturnValue(ok(listenerOverview([listenerStatus("socket-1")])));
    const user = userEvent.setup();
    render(<ListenersView />);

    await user.click(await screen.findByRole("button", { name: "保存当前监听" }));

    await waitFor(() => expect(mocks.listenerSave).toHaveBeenCalledOnce());
    const saved = mocks.listenerSave.mock.calls[0][2];
    expect(saved.data_plane).toEqual(socket.data_plane);
    expect(JSON.stringify(saved.data_plane)).not.toMatch(
      /authentication|mitm|fixed_server|downstream_tls|request_body_codec/,
    );
  });

  it("Socket 连接探测 pending 时禁止重复触发", async () => {
    const socket = socketListener("socket-1", "Socket", 9000, "tcp_to_tls");
    mocks.workspaceGet.mockReturnValue(ok({ ...workspace, listeners: [socket] }));
    mocks.listenerOverview.mockReturnValue(ok(listenerOverview([listenerStatus("socket-1")])));
    mocks.listenerTestUpstreamConnection.mockReturnValue(new Promise(() => undefined));
    const user = userEvent.setup();
    render(<ListenersView />);

    const testButton = await screen.findByRole("button", { name: "测试 Server 连接" });
    await user.click(testButton);

    expect(await screen.findByRole("button", { name: "正在探测 Server…" })).toBeDisabled();
    expect(mocks.listenerDraftValidate).toHaveBeenCalledOnce();
    expect(mocks.listenerTestUpstreamConnection).toHaveBeenCalledOnce();
  });

  it("Socket 使用 IP 连接时从证书自动填写 TLS Server Name 并要求再次严格测试", async () => {
    const socket = socketListener("socket-1", "Socket", 9000, "tcp_to_tls");
    socket.data_plane.settings.topology.settings.upstream.host = "113.197.126.77";
    mocks.workspaceGet.mockReturnValue(ok({ ...workspace, listeners: [socket] }));
    mocks.listenerOverview.mockReturnValue(ok(listenerOverview([listenerStatus("socket-1")])));
    mocks.listenerTestUpstreamConnection
      .mockReturnValueOnce(ok({
        listener_id: "socket-1",
        data_plane: "socket",
        upstream_origin: "113.197.126.77:9443",
        resolved_address: "113.197.126.77:9443",
        scheme: "socket",
        transport: "tls",
        tls: {
          tls_version: "TLS 1.2",
          cipher_suite: "AES256-GCM-SHA384",
          peer_subject: "CN=testssl.tnsi.com.au",
          peer_sha256_fingerprint: "AA:BB",
          hostname_verification_enabled: false,
          client_identity_configured: false,
        },
        socket_transport_mode: "tcp_to_tls",
        tls_server_name_candidates: ["testssl.tnsi.com.au"],
        elapsed_millis: 12,
        message: "Server 证书链验证成功，已自动填写 TLS Server Name；请再次测试以完成严格主机名校验。",
        ui_tone: "warning",
      }))
      .mockReturnValueOnce(ok({
        listener_id: "socket-1",
        data_plane: "socket",
        upstream_origin: "113.197.126.77:9443",
        resolved_address: "113.197.126.77:9443",
        scheme: "socket",
        transport: "tls",
        tls: {
          tls_version: "TLS 1.2",
          cipher_suite: "AES256-GCM-SHA384",
          peer_subject: "CN=testssl.tnsi.com.au",
          peer_sha256_fingerprint: "AA:BB",
          hostname_verification_enabled: true,
          client_identity_configured: false,
        },
        socket_transport_mode: "tcp_to_tls",
        elapsed_millis: 10,
        message: "上游 Socket tls 连接成功。",
        ui_tone: "positive",
      }));
    const user = userEvent.setup();
    render(<ListenersView />);

    await user.click(await screen.findByRole("button", { name: "测试 Server 连接" }));

    expect(await screen.findByRole("textbox", { name: "Socket TLS Server Name" }))
      .toHaveValue("testssl.tnsi.com.au");
    expect(screen.getByRole("textbox", { name: "Socket Server 主机" }))
      .toHaveValue("113.197.126.77");
    expect(screen.getByText(/请再次测试以完成严格主机名校验/)).toBeVisible();

    await user.click(screen.getByRole("button", { name: "测试 Server 连接" }));
    await waitFor(() => expect(mocks.listenerTestUpstreamConnection).toHaveBeenCalledTimes(2));
    const retested = mocks.listenerTestUpstreamConnection.mock.calls[1][2];
    expect(retested.data_plane.settings.topology.settings.upstream.host).toBe("113.197.126.77");
    expect(retested.data_plane.settings.topology.settings.security.upstream_tls.tls_server_name)
      .toBe("testssl.tnsi.com.au");
    expect(await screen.findByText("上游 Socket tls 连接成功。")).toBeVisible();
  });

  it("LocalResponder 可启动和复制且不读取或探测不存在的 Server 上游", async () => {
    const local = localResponderListener();
    mocks.workspaceGet.mockReturnValue(ok({ ...workspace, listeners: [local] }));
    mocks.listenerOverview.mockReturnValue(ok(listenerOverview([listenerStatus(local.id)])));
    const user = userEvent.setup();
    render(<ListenersView />);

    expect(await screen.findByText("→ 本地应答")).toBeVisible();
    expect(screen.getByText("Socket · 本地应答")).toBeVisible();
    expect(screen.getByRole("button", { name: "启动监听" })).toBeEnabled();
    expect(screen.getByRole("button", { name: "复制监听" })).toBeEnabled();
    expect(screen.queryByRole("textbox", { name: "Socket Server 主机" })).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "测试 Server 连接" })).not.toBeInTheDocument();
    await user.click(screen.getByRole("button", { name: "复制监听" }));
    expect(mocks.listenerDraftCopy).toHaveBeenCalledWith(local);
    expect(mocks.listenerTestUpstreamConnection).not.toHaveBeenCalled();
  });

  it("Socket 运行卡展示 Rust 协议标签、活动连接和双向字节", async () => {
    const socket = socketListener("socket-1", "Socket 入口", 9000, "tls_to_tls");
    const running = {
      ...listenerStatus("socket-1", "running"),
      kind_text: "Socket · TLS → TLS",
    };
    mocks.workspaceGet.mockReturnValue(ok({ ...workspace, listeners: [socket] }));
    mocks.listenerOverview.mockReturnValue(ok(listenerOverview([running])));

    render(<ListenersView />);

    expect(await screen.findByText("Socket · TLS → TLS")).toBeVisible();
    expect(await screen.findByText(
      "活动连接 2 · C→S 1.0 KiB · S→C 2.0 KiB",
    )).toBeVisible();
  });

});
